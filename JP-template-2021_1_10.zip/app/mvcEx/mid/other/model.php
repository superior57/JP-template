<?php

	//★クラス //

	/**
		@brief   既定の静的ページのモデル。
	*/
	class AppmidOtherModel extends AppOtherModel //
	{}
