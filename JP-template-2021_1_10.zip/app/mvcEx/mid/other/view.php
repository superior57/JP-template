<?php

	//★クラス //

	/**
		@brief 既定の静的ページのビュー。
	*/
	class AppmidOtherView extends AppOtherView //
	{}
