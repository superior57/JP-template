<?php

	//★クラス //

	/**
		@brief   既定のインデックスページのモデル。
	*/
	class AppIndexModel extends AppBaseModel //
	{}
