<?php

	//★クラス //

	/**
		@brief   既定のインデックスページのモデル。
	*/
	class AppDirectMailModel extends AppBaseModel //
	{}
