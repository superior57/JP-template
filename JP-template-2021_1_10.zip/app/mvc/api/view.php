<?php

	//★クラス //

	/**
		@brief 既定のAPIのビュー。
	*/
	class AppAPIView extends AppBaseView //
	{}
