<?php

	//★クラス //

	/**
		@brief 既定の管理ツールのダウンロード処理のモデル。
	*/
	class AppDownloadModel extends AppBaseModel //
	{}
