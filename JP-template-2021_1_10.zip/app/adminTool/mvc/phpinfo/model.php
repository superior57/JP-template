<?php

	//★クラス //

	/**
		@brief 既定の管理ツールのphpinfo表示処理のモデル。
	*/
	class AppPHPInfoModel extends AppBaseModel //
	{}
