<?php
	include_once './custom/download/commonDL.php';
	include_once './custom/download/entryDownload.php';
	include_once './custom/download/payJobDownload.php';
	include_once './custom/download/billDownload.php';