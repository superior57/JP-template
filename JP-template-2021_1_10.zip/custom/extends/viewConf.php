<?php

	include_once './custom/view/PageView.php';
	include_once './custom/view/AreaView.php';