<?php

	// システム出力フォームのactinon( normal:通常 index:index.php?app_controller=... null:空白 )
	define( 'WS_SYSTEM_SYSTEM_FORM_ACTON' , 'index' );

	// 各種入力画面からGETで送信する遷移識別用パラメータ
	define( 'WS_SYSTEM_SYSTEM_FORM_INPUT_LABEL' , 'by=form' );

	// 各種確認画面からGETで送信する遷移識別用パラメータ
	define( 'WS_SYSTEM_SYSTEM_FORM_CHECK_LABEL' , 'by=check' );
