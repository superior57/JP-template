<?php

	$SYSTEM_CHECK_VERSION[] = 'php';
	$SYSTEM_CHECK_VERSION[] = 'mysql';
	$SYSTEM_CHECK_VERSION[] = 'sqlite';
	$SYSTEM_CHECK_VERSION[] = 'gd';
	$SYSTEM_CHECK_VERSION[] = 'pdo';
	$SYSTEM_CHECK_VERSION[] = 'openssl';
	$SYSTEM_CHECK_VERSION[] = 'json';
	$SYSTEM_CHECK_VERSION[] = 'curl';
