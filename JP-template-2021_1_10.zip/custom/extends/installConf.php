<?php
	$SYSTEM_INSTALL_STATUS[ 'permission' ] = true;
	$SYSTEM_INSTALL_STATUS[ 'verify' ] = true;
	$SYSTEM_INSTALL_STATUS[ 'db' ] = true;
	$SYSTEM_INSTALL_STATUS[ 'password' ] = true;
	$SYSTEM_INSTALL_STATUS[ 'table' ] = true;
	$SYSTEM_INSTALL_STATUS[ 'misc' ] = true;
	$SYSTEM_INSTALL_STATUS[ 'complete' ] = true;
