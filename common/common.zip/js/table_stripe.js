
$(function() {
	$('.list_table tr:nth-child(odd)').addClass('odd');
});
